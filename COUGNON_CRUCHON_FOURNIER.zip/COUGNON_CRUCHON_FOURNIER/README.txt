=-=-=-=-=-=-=-=-=-= Projet base de données =-=-=-=-=-=-=-=-=-=

=-=-=-=-=-=	COUGNON Alexandre

=-=-=-=-=-= FOURNIER Alexandre

=-=-=-=-=-= CRUCHON Joachim


=-=-=-=-=-=-=-=-=-= Utilisation de la base =-=-=-=-=-=-=-=-=-=

Pour générer notre base de données, il faut exécuter le script du fichier Create_Table.sql

Ce fichier va dans un premier temps créer les tables, ajouter les contraintes d'intégrités, puis les triggers et enfin remplir la table de données.

Ensuite, vous trouverez dans le fichier Transactions_Requete.sql, les transactions effectuées manuellement et les requêtes de la partie 6 du sujet.