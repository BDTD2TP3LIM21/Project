-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= --
-- Create_Table.sql COUGNON Alexandre, CRUCHON Joachim, FOURNIER Alexandre --
-- =-=-=-=-=-=-=-=-=-=-=-=- L3 Informatique - TP3 -=-=-=-=-=-=-=-=-=-=-=-= --
-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= --

-- =-=-=-=-= Partie 2. Cr�ation de la base de donn�es multim�dia =-=-=-=-= --

DROP TABLE Authors CASCADE CONSTRAINTS;
CREATE TABLE Authors (
  Id_authors INT, 
  Name_authors VARCHAR2(100), 
  Surname_authors VARCHAR2(100), 
  Birthday DATE,
  CONSTRAINT PK_Authors PRIMARY KEY (Id_authors));
  
DROP TABLE Key_words CASCADE CONSTRAINTS;
CREATE TABLE Key_words (
  Name_key_words VARCHAR2(100),
  CONSTRAINT PK_Key_words PRIMARY KEY(Name_key_words));


DROP TABLE Editors CASCADE CONSTRAINTS;
CREATE TABLE Editors (
  Name_editors VARCHAR2(100), 
  Adresse VARCHAR2(255), 
  Phone_number VARCHAR2(50), 
  CONSTRAINT PK_Editors PRIMARY KEY (Name_editors));

DROP TABLE Categories CASCADE CONSTRAINTS;
CREATE TABLE Categories (
  Name_categories VARCHAR2(255),
  Nb_doc_max INT,
  Time_book INT,
  Time_CD INT,
  Time_DVD INT,
  Time_Video INT,
  CONSTRAINT PK_Categories PRIMARY KEY (Name_categories));

DROP TABLE Borrowers CASCADE CONSTRAINTS;
CREATE TABLE Borrowers (
  Id_borrower INT, 
  Name_borrower VARCHAR2(255),
  Surname_borrower VARCHAR2(255),
  Adresse VARCHAR2(255), 
  Phone_number VARCHAR2(255),
  Name_categorie VARCHAR2(255),
  CONSTRAINT PK_Borrowers PRIMARY KEY (Id_borrower),
  CONSTRAINT FK_Borrowers_Categories FOREIGN KEY(Name_categorie) REFERENCES Categories(Name_categories));
  
DROP TABLE Documents CASCADE CONSTRAINTS;
CREATE TABLE Documents (
  Id_documents INT, 
  Title VARCHAR2(255),
  Theme VARCHAR2(255),
  Editor VARCHAR2(255),
  CONSTRAINT PK_Documents PRIMARY KEY (Id_documents),
  CONSTRAINT FK_Documents_Editor FOREIGN KEY(Editor) REFERENCES Editors(Name_Editors));
  
DROP TABLE Exemplar CASCADE CONSTRAINTS;
CREATE TABLE Exemplar (
  Id_Exemplar INT,
  Shelf INT NOT NULL,
  Documents INT,
  CONSTRAINT PK_Exemplar PRIMARY KEY (Id_Exemplar),
  CONSTRAINT FK_Exemplar_Documents FOREIGN KEY(Documents) REFERENCES Documents(Id_Documents));

DROP TABLE Described CASCADE CONSTRAINTS;
CREATE TABLE Described (
  Documents INT,
  Key_Word VARCHAR2(100),
  CONSTRAINT PK_Described PRIMARY KEY (Documents, Key_Word),
  CONSTRAINT FK_Described_Documents FOREIGN KEY (Documents) REFERENCES Documents(Id_documents),
  CONSTRAINT FK_Described_Key_words FOREIGN KEY (Key_Word) REFERENCES Key_words(Name_key_words));
  
    
DROP TABLE Wrote CASCADE CONSTRAINTS;
CREATE TABLE Wrote (
  Documents INT,
  Author INT,
  CONSTRAINT PK_Wrote PRIMARY KEY (Documents, Author),
  CONSTRAINT FK_Wrote_Documents FOREIGN KEY (Documents) REFERENCES Documents(Id_documents),
  CONSTRAINT FK_Wrote_Authors FOREIGN KEY (Author) REFERENCES Authors(Id_authors));
  
DROP TABLE Borrows CASCADE CONSTRAINTS;
CREATE TABLE Borrows (
  Borrower INT,
  Exemplar INT,
  Begin_borrow DATE,
  End_borrow DATE,
  CONSTRAINT PK_Borrows PRIMARY KEY (Borrower, Exemplar, Begin_borrow, End_borrow),
  CONSTRAINT FK_Borrows_Borrower FOREIGN KEY (Borrower) REFERENCES Borrowers(Id_borrower),
  CONSTRAINT FK_Borrows_Exemplar FOREIGN KEY (Exemplar) REFERENCES Exemplar(Id_Exemplar));
  
DROP TABLE Books CASCADE CONSTRAINTS;
CREATE TABLE Books (
  Id_books INT, 
  Documents INT,
  Nb_pages INT,
  CONSTRAINT PK_Books PRIMARY KEY (Id_books),
  CONSTRAINT FK_Books_Documents FOREIGN KEY(Documents) REFERENCES Documents(Id_Documents));

DROP TABLE DVD CASCADE CONSTRAINTS;
CREATE TABLE DVD (
  Id_DVD INT, 
  Documents INT,
  Duration_DVD NUMBER(10,2),
  CONSTRAINT PK_DVD PRIMARY KEY (Id_DVD),
  CONSTRAINT FK_DVD_Documents FOREIGN KEY(Documents) REFERENCES Documents(Id_Documents));
  
DROP TABLE CD CASCADE CONSTRAINTS;
CREATE TABLE CD (
  Id_CD INT, 
  Documents INT,
  Duration_CD NUMBER(10,2),
  Nb_subtitles INT,
  CONSTRAINT PK_CD PRIMARY KEY (Id_CD),
  CONSTRAINT FK_CD_Documents FOREIGN KEY(Documents) REFERENCES Documents(Id_Documents));
  
DROP TABLE Videos CASCADE CONSTRAINTS;
CREATE TABLE Videos (
  Id_Videos INT, 
  Documents INT,
  Duration_Videos NUMBER(10,2),
  Extension VARCHAR2(5),
  CONSTRAINT PK_Videos PRIMARY KEY (Id_videos),
  CONSTRAINT FK_Videos_Documents FOREIGN KEY(Documents) REFERENCES Documents(Id_Documents));
 
 
ALTER TABLE Books
ADD CONSTRAINT CK_Books_Pages CHECK (nb_pages > 0 );

ALTER TABLE CD
ADD CONSTRAINT CK_CD_Subtitles CHECK (nb_subtitles > 0 );

ALTER TABLE DVD
ADD CONSTRAINT CK_DVD_Duration CHECK (duration_dvd > 0 );

ALTER TABLE CD
ADD CONSTRAINT CK_CD_Duration CHECK (duration_cd > 0 );

ALTER TABLE Videos
ADD CONSTRAINT CK_Videos_Duration CHECK (duration_videos > 0 );

ALTER TABLE Videos
ADD CONSTRAINT CK_Videos_Extension CHECK (extension ='flv' OR extension ='avi' OR extension = 'mov' OR extension ='mp4' OR extension = 'wmv');

-- =-=-=-=-=- Partie 4. V�rification de la coh�rence de la base -=-=-=-=-= --

    -- =-=-=-=-=-=-=-=-=-=-=-=-= Triggers =-=-=-=-=-=-=-=-=-=-=-=-= --
DROP SEQUENCE id_author;
CREATE SEQUENCE id_author;

create or replace trigger trig_authors_id
before insert or update on authors
for each row
begin
select id_author.NEXTVAL INTO :new.id_authors FROM DUAL;
END;
/

DROP SEQUENCE id_book;
CREATE SEQUENCE id_book;

create or replace trigger trig_books_id
before insert or update on books
for each row
begin
select id_book.NEXTVAL INTO :new.id_books FROM DUAL;
END;
/

DROP SEQUENCE id_borrowers;
CREATE SEQUENCE id_borrowers;

create or replace trigger trig_borrower_id
before insert or update on borrowers
for each row
begin
select id_borrowers.NEXTVAL INTO :new.id_borrower FROM DUAL;
END;
/

DROP SEQUENCE id_exemplar;
CREATE SEQUENCE id_exemplar;

create or replace trigger trig_exemplar_id
before insert or update on exemplar
for each row
begin
select id_exemplar.NEXTVAL INTO :new.id_exemplar FROM DUAL;
END;
/

DROP SEQUENCE CD_id;
CREATE SEQUENCE CD_id;

create or replace trigger trig_CD_id
before insert or update on CD
for each row
begin
select CD_id.NEXTVAL INTO :new.id_CD FROM DUAL;
END;
/

DROP SEQUENCE DVD_id;
CREATE SEQUENCE DVD_id;

create or replace trigger trig_DVD_id
before insert or update on DVD
for each row
begin
select DVD_id.NEXTVAL INTO :new.id_DVD FROM DUAL;
END;
/

DROP SEQUENCE id_video;
CREATE SEQUENCE id_video;

create or replace trigger trig_videos_id
before insert or update on videos
for each row
begin
select id_video.NEXTVAL INTO :new.id_videos FROM DUAL;
END;
/

create or replace trigger trig_authors_birthday
before insert or update on authors
for each row
begin
if ((sysdate - :new.birthday)/365.25) < 0 then
raise_application_error('-20001', 'Birthday cannot be in the future');
end if;
end;
/

create or replace trigger trig_books_pages
before insert or update on books
for each row
begin 
if (:new.nb_pages <= 0) then
raise_application_error('-20001', 'The number of pages cannot be negative');
end if;
end;
/

create or replace trigger trig_borrows_begin_end
before insert or update on borrows
for each row
begin
if (:new.begin_borrow > :new.end_borrow) then
raise_application_error('-20001', 'Begin of borrows must be before the end');
end if;
end;
/


-- V�rifie que le documents n'est pas d�j� emprunt�
create or replace trigger trig_borrows_available
before insert or update on borrows
for each row
declare cpt number; 
BEGIN
select COUNT(exemplar) into cpt
from borrows
where exemplar = :new.exemplar and end_borrow > sysdate;
if cpt > 0
then
    raise_application_error('-20001', 'The documents is arleady borrows');
end if;
end;
/

-- V�rifie que l'emprunteur n'a pas d�j� la maximum de documents emprunt�s
create or replace trigger trig_borrows_number
before insert or update on borrows
for each row
declare cpt number;
BEGIN
declare nb_max integer;
BEGIN
select COUNT(*) into cpt
from borrows
where borrower = :new.borrower and end_borrow > sysdate;

select nb_doc_max into nb_max
from categories, borrowers
where borrowers.id_borrower = :new.borrower and borrowers.name_categorie = categories.name_categories;
if (cpt >= nb_max)
then
    raise_application_error('-20001', 'The limit of documents achieved');
end if;
end;
end;
/

-- Verifie que l'emprunt supprim� n'est pas en cours d'emprunt 
create or replace trigger trig_borrows_delete_check
before delete on borrows
for each row
declare cpt number; 
BEGIN
select COUNT(*) into cpt
from borrows
where exemplar = :old.exemplar and :old.end_borrow > sysdate;
if cpt > 0
then
    raise_application_error('-20001', 'This borrows have to be end for delete');
end if;
end;
/

-- Verifie que l'emprunteur supprim� n'a pas d'emprunt en cours
create or replace trigger trig_borrower_delete_check
before delete on borrowers
for each row
declare cpt number; 
BEGIN
select COUNT(*) into cpt
from borrows, borrowers
where borrower = :old.id_borrower and end_borrow > sysdate;
if cpt > 0
then
    raise_application_error('-20001', 'The borrower have some borrows in process');
end if;
end;
/

-- Verifie que l'exemplair supprim� n'est pas en cours d'emprunt
create or replace trigger trig_exemplar_delete_check
before delete on exemplar
for each row
declare cpt number; 
BEGIN
select COUNT(*) into cpt
from borrows, exemplar
where exemplar = :old.id_exemplar and end_borrow > sysdate;
if cpt > 0
then
    raise_application_error('-20001', 'This exemplar is in process of borrowing');
end if;
end;
/

-- V�rifie que l'emprunteur n'est pas en retard sur un de ces doccuments
-- Dans notre base actuelle nous ne pouvons pas conna�tre la nature d'un documents juste avec son id
-- On ne peut donc pas savoir � quoi se r�f�re le nombre de semaine max d'un emprunt

-- =-=-=-=-=-=-=-=-= Partie 5. Remplissage de la table =-=-=-=-=-=-=-=-=-= --

-- Authors 

INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Jo�l', 'DICKER',  '16/06/1985') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Chu', 'GONG',  '23/10/1988') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Adam', 'WOODWORTH',  '06/01/1976') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Immanuel', 'KANT',  '22/04/1724') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Pierre', 'BOUTRON',  '11/11/1947') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Jean-Claude', 'NACHON',  '25/05/1963') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Ang�lique', 'NACHON',  '09/04/1975') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Arnaud', 'VIARD',  '22/08/1965') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Benjamin', 'BIOLAY',  '24/01/1973') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Georges', 'LAUTNER',  '24/01/1926') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Richard', 'CARON',  '30/12/1933') ;

INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'P.J', 'HOGAN',  '30/11/1962') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Jarvis', 'TAVERNIER',  '01/01/1963') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Kevin', 'MORBY',  '01/06/1958') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Timoth�', 'MERCADAL',  '29/12/1997') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Katheryn', 'HUDSON',  '25/10/1984') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'David', 'CASTELLO-LOPES',  '16/09/1981') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Kyan', 'JHOJANDI',  '29/10/1979') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Cyprien', 'IOV',  '26/03/1983') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Butters', 'PARKSOUTH',  '25/08/1991') ;
	
INSERT INTO AUTHORS(ID_AUTHORS ,NAME_AUTHORS , SURNAME_AUTHORS,  BIRTHDAY)
    VALUES (0 , 'Thibaut', 'GIRAUD',  '30/04/1987') ;

-- Editors

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Edition de Fallois', '22 Rue la Bo�tie, 75008 Paris' ,  '01 42 66 91 95');
    
INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('DUNOD', '11 Rue Paul Bert, 92247 Malakoff' ,  '01 41 23 66 00');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Eyrolles', '55-57-61 Boulevard Saint-Germain, 75005 Paris' ,  '03 21 79 56 75');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('DNC media', '93-2 Myeong Dong SEOUL' ,  '02 333 2514');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Hachette', '58 Rue Jean Bleuzen, 92170 Vanves' ,  '01 43 25 36 85');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Expand Drama', '65 Rue de la gare, 93200 SAINT-DENIS' ,  '04 85 84 14 01');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Gloria films', '26 Rue de la Mairie, 75014 Paris' ,  '09 44 48 15 26');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Les productions de la Lanterne', '8 AV LA PORTE DE MONTROUGE, 75014 PARIS' ,  '06 36 30 36 30');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Gaumont', '30 avenue Charles de Gaulle Nantes 44300' ,  '05 83 12 32 55');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Columbia pictures', 'Thalberg Building, 10202 West Washington Boulevard, Culver City, California , United States' ,  '08 98 48 16 67');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Differ Ant', '4 rue du haut des sables, 86000 Poitiers' ,  '05 49 48 47 46');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Poney Gris', '10 rue de l �tang , 12634 Plessis-Robinssons' ,  '04 06 93 94 51');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Virgin Records', '15 rue de l H�tel Dieu, 86000 Poitiers' ,  '05 49 45 30 00');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('CANAL+ France', '35 Rue de la Clairi�re, 45000 Orl�ans' ,  '07 15 36 55 89 ');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Youtube', '65 Rue du Moulin, 75000 Paris' ,  '08 09 44 26 14 ');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Tev and Louis', '901 Cherry Ave � San Bruno, CA 94066' ,  '1 650-253-0000');

INSERT INTO EDITORS(NAME_EDITORS , ADRESSE , PHONE_NUMBER)
    VALUES ('Vortex', 'Arte 8 r Marceau, 92130 Issy les Moulineaux' ,  '01 55 00 77 77');
    
    
-- Categories

INSERT INTO CATEGORIES(NAME_CATEGORIES , NB_DOC_MAX, TIME_BOOK, TIME_CD, TIME_DVD, TIME_VIDEO)
    VALUES ('Personnel', 10, 9, 5, 4, 3);
    
INSERT INTO CATEGORIES(NAME_CATEGORIES , NB_DOC_MAX, TIME_BOOK, TIME_CD, TIME_DVD, TIME_VIDEO)
    VALUES ('Professionnel', 5, 11, 4, 3, 2);
    
INSERT INTO CATEGORIES(NAME_CATEGORIES , NB_DOC_MAX, TIME_BOOK, TIME_CD, TIME_DVD, TIME_VIDEO)
    VALUES ('Public', 3, 3, 3, 2, 1);

-- Borrowers

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Dupont', 'Dupont', '77 rue du pont St Marc', '06 52 95 62 45', 'Public');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Richard', 'Arbani', '119 rue du chapeau', '07 52 17 58 40', 'Personnel');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Grosse', 'Bertha', '27 boulevard Allemand', '06 06 06 06 06', 'Public');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Gille', 'centzes', '231 boulevard de l`obellisque', '07 60 99 48 26', 'Professionnel');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Marcel', 'Pontans', '77 rue du pont St Marc', '07 50 06 35 86', 'Professionnel');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'David', 'Newell', '789 avenue de l`h�tel Aurore', '04 12 68 29 48', 'Personnel');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'L�a', 'Lanau', '231 boulevard de l`obellisque', '07 52 21 23 55', 'Public');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Marine', 'Picon', '14 rue Jean-Charles Vaint', '06 30 51 45 26', 'Public');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Aria', 'Maldin', '8 chemin de l`olivier', '08 09 77 15 26', 'Professionnel');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Martin', 'Avok', '16 avenue point de croix', '04 44 59 28 17', 'Personnel');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Arthur', 'Chevallais', '78 boulevard du vieux port', '08 09 75 15 29', 'Public');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'El�ne', 'Francine', '11 chemin de l`ancien moulin', '05 22 64 18 22', 'Public');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Esteban', 'Lovreau', '16 avenue point de croix', '07 09 88 51 88', 'Public');
 
INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Ana�s', 'Sarone', '77 rue du pont St Marc', '07 88 09 77 48', 'Personnel');

INSERT INTO BORROWERS(ID_BORROWER, NAME_BORROWER, SURNAME_BORROWER, ADRESSE, PHONE_NUMBER, NAME_CATEGORIE)
    VALUES (0, 'Alain', 'Tarn', '142 rue du petit pont', '02 52 68 54 25', 'Professionnel');
    

-- KeyWords

INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('HORREUR');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('CATASTROPHE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('DRAMATIQUE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('SURNATUREL');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('ART MARTIAUX');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('CRIME');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('ESPIONNAGE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('MIRACLE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('TRAG�DIE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('AMOUR');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('AMITIE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('CHASSE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('SIBERIE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('MASSACRE');

INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('ECONOMIE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('VIETNAM');

INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('CORRUPTION');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('NOURRITURE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('JAPON');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('INMANGEABLE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('PHYSIQUE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('ASTRONOMIE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('HISTOIRE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('PHILOSOPHIE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('ACTION');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('AVENTURE');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('SCIENCE-FICTION');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('FANTASY');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('FUN');
    
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('EXPLORATION');

INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('QUANTIQUE');

INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('ALGORITHMIQUE');
	
INSERT INTO Key_WORDS(NAME_KEY_WORDS)
    VALUES('PROGRAMATION');
    
-- Parties Documents --
    
-- Documents

INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (1, 'LE TIGRE', 'Nouvelle', 'Edition de Fallois');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (2, 'LA VERITE DES BALTIMORE', 'ROMAN', 'DUNOD');
 
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (3, 'PHOTOGRAPHIER LE CIEL NOCTURNE', 'DOCUMENTAIRE', 'Eyrolles');
   
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (4, 'SOLO LEVELING', 'Manga', 'DNC media');
  
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (5, 'TRAITE DE PEDAGOGIE', 'Philosophie', 'DUNOD');
             
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (6, 'JAVA pour les nuls', 'Informatique d�butant', 'Hachette');

INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (7, 'SQL pour les nuls', 'Informatique d�butant', 'Hachette');
 
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (8, 'Th�orie de la g�om�trie ir�el', 'Math�matiques', 'Edition de Fallois');

INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (9, 'Th�orie du r�seaux quantiques', 'Informatique', 'Edition de Fallois');

INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (10, 'Analyse du son au travers des maths', 'Math�matiques', 'Poney Gris');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (11, 'With light and with love', 'Musique Rock', 'Differ Ant');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (12, 'L`impalpable', 'Musique Electro', 'Differ Ant');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (13, 'Exp�rience', 'Musique Electro', 'Poney Gris');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (14, 'Katy Perry Teenage Dream', 'Musique Pop', 'Virgin Records');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (15, 'Je suis suisse', 'Musique Bizarre', 'Poney Gris');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (16, '52 - Bref. Je suis en couple', 'Com�die', 'CANAL+ France');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (17, 'LES R�UNIONS 5', 'Com�die', 'Youtube');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (18, 'Les nouveaux capitaliste', 'Documentaire', 'Poney Gris');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (19, 'Le couscous au japon', 'Com�die', 'Tev and Louis');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (20, 'Tu n`es pas le centre du monde', '�ducatif', 'Vortex');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (21, 'LE SILENCE DE LA MER', 'Biographie', 'Expand Drama');

INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (22, 'CLARA ET MOI','Commentaire audio', 'Gloria films');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (23, 'SIA, LE R�VE DU PYTHON' ,'Histoire afrique', 'Les productions de la Lanterne');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (24, 'IL �TAIT UNE FOIS UN FLIC' ,'Film Policier' , 'Gaumont');
    
INSERT INTO DOCUMENTS(ID_DOCUMENTS, TITLE, THEME, EDITOR)
    VALUES (25, 'PETER PAN' , 'Fiction Fantastique', 'Columbia pictures');

-- Described

INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(1, 'CHASSE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(1, 'SIBERIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(1, 'MASSACRE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(2, 'PHYSIQUE');

INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(2, 'ASTRONOMIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(3, 'MIRACLE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(3, 'ACTION');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(3, 'FANTASY');

INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(4, 'AMOUR');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(4, 'DRAMATIQUE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(4, 'CORRUPTION');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(5, 'HISTOIRE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(5, 'PHILOSOPHIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(6, 'PROGRAMATION');
	
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(6, 'ALGORITHMIQUE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(7, 'PROGRAMATION');
	
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(7, 'ALGORITHMIQUE');
	
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(8, 'ALGORITHMIQUE');		
	
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(9, 'ALGORITHMIQUE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(9, 'QUANTIQUE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(9, 'PROGRAMATION');
	
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(10, 'ALGORITHMIQUE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(11, 'PHILOSOPHIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(11, 'ASTRONOMIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(11, 'PHYSIQUE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(12, 'AVENTURE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(12, 'ACTION');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(12, 'VIETNAM');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(13, 'MIRACLE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(13, 'ART MARTIAUX');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(14, 'AMITIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(14, 'EXPLORATION');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(14, 'AVENTURE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(15, 'NOURRITURE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(15, 'FUN');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(16, 'HISTOIRE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(16, 'INMANGEABLE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(17, 'CRIME');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(17, 'AMOUR');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(17, 'TRAG�DIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(18, 'FANTASY');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(18, 'SURNATUREL');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(18, 'JAPON');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(19, 'ASTRONOMIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(19, 'SIBERIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(20, 'MASSACRE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(20, 'VIETNAM');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(21, 'ESPIONNAGE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(21, 'ACTION');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(21, 'ECONOMIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(22, 'HORREUR');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(22, 'CRIME');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(22, 'CHASSE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(23, 'CATASTROPHE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(23, 'HISTOIRE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(23, 'ECONOMIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(24, 'FUN');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(24, 'ASTRONOMIE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(25, 'NOURRITURE');
    
INSERT INTO DESCRIBED(DOCUMENTS, KEY_WORD)
    VALUES(25, 'JAPON');

    
-- Wrote
 
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(1, 1);
 
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(2, 1);

INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(3, 3);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(4, 2);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(5, 4);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(6, 9);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(7, 8);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(8, 8);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(9, 17);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(10, 10);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(11, 13);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(11, 14);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(12, 13);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(12, 14);

INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(13, 15);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(14, 16);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(15, 15);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(16, 18);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(17, 19);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(18, 20);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(19, 20);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(20, 21);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(21, 5);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(21, 6);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(21, 7);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(22, 8);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(22, 9);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(23, 10);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(23, 11);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(24, 10);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(24, 11);
    
INSERT INTO WROTE(DOCUMENTS, AUTHOR)
    VALUES(25, 12); 
   
-- Books

INSERT INTO BOOKS(ID_BOOKS, DOCUMENTS, NB_PAGES)
    VALUES (0, 1, 64);
    
INSERT INTO BOOKS(ID_BOOKS, DOCUMENTS, NB_PAGES)
    VALUES (0, 2, 480);
    
INSERT INTO BOOKS(ID_BOOKS, DOCUMENTS, NB_PAGES)
    VALUES (0, 3, 320);
    
INSERT INTO BOOKS(ID_BOOKS, DOCUMENTS, NB_PAGES)
    VALUES (0, 4, 182);
        
INSERT INTO BOOKS(ID_BOOKS, DOCUMENTS, NB_PAGES)
    VALUES (0, 5, 248);
   
/* math�matique / informatique */
    
INSERT INTO BOOKS(ID_BOOKS, DOCUMENTS, NB_PAGES)
    VALUES (0, 6, 300);
	    
INSERT INTO BOOKS(ID_BOOKS, DOCUMENTS, NB_PAGES)
    VALUES (0, 7, 500);
    
INSERT INTO BOOKS(ID_BOOKS, DOCUMENTS, NB_PAGES)
    VALUES (0, 8, 15);
    
INSERT INTO BOOKS(ID_BOOKS, DOCUMENTS, NB_PAGES)
    VALUES (0, 9, 480);
    
INSERT INTO BOOKS(ID_BOOKS, DOCUMENTS, NB_PAGES)
    VALUES (0, 10, 220);
-- CD

INSERT INTO CD(ID_CD, DOCUMENTS, DURATION_CD, NB_SUBTITLES)
    VALUES (0, 11, 43.24 , 10);

INSERT INTO CD(ID_CD, DOCUMENTS, DURATION_CD, NB_SUBTITLES)
    VALUES (0, 12, 33.56, 8);
    
INSERT INTO CD(ID_CD, DOCUMENTS, DURATION_CD, NB_SUBTITLES)
    VALUES (0, 13, 12.21, 8);
    
INSERT INTO CD(ID_CD, DOCUMENTS, DURATION_CD, NB_SUBTITLES)
    VALUES (0, 14, 77, 13);
    
INSERT INTO CD(ID_CD, DOCUMENTS, DURATION_CD, NB_SUBTITLES)
    VALUES (0, 15, 1.32, 1);


-- Vid�o

INSERT INTO VIDEOS(ID_VIDEOS, DOCUMENTS, DURATION_VIDEOS, EXTENSION)
    VALUES (0, 16, 1.42, 'mov');

INSERT INTO VIDEOS(ID_VIDEOS, DOCUMENTS, DURATION_VIDEOS, EXTENSION)
    VALUES (0, 17, 5.54, 'mp4');
    
INSERT INTO VIDEOS(ID_VIDEOS, DOCUMENTS, DURATION_VIDEOS, EXTENSION)
    VALUES (0, 18, 8.03, 'mp4');
    
INSERT INTO VIDEOS(ID_VIDEOS, DOCUMENTS, DURATION_VIDEOS, EXTENSION)
    VALUES (0, 19, 12.55, 'avi');
    
INSERT INTO VIDEOS(ID_VIDEOS, DOCUMENTS, DURATION_VIDEOS, EXTENSION)
    VALUES (0, 20, 21.12, 'wmv');    


-- DVD

INSERT INTO DVD(ID_DVD, DOCUMENTS, DURATION_DVD)
    VALUES(0, 21, 92);
    
INSERT INTO DVD(ID_DVD, DOCUMENTS, DURATION_DVD)
    VALUES(0, 22, 80);
    
INSERT INTO DVD(ID_DVD, DOCUMENTS, DURATION_DVD)
    VALUES(0, 23, 96);
    
INSERT INTO DVD(ID_DVD, DOCUMENTS, DURATION_DVD)
    VALUES(0, 24, 93);
    
INSERT INTO DVD(ID_DVD, DOCUMENTS, DURATION_DVD)
    VALUES(0, 25, 108);

-- EXEMPLAR
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 100, 1);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 101, 2);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 102, 3);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 103, 4);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 104, 5);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 105, 6);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 106, 7);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 107, 8);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 108, 9);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 109, 10);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 200, 11);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 201, 12);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 202, 13);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 203, 14);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 204, 15);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 300, 16);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 301, 17);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 302, 18);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 303, 19);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 304, 20);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 400, 21);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 401, 22);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 402, 23);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 403, 24);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 404, 25);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 102, 3);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 102, 3);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 102, 3);
    
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 105, 6);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 105, 6);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 107, 8);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 107, 8);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 109, 10);
    
INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 204, 15);

INSERT INTO EXEMPLAR(ID_EXEMPLAR, SHELF, DOCUMENTS)
    VALUES(0, 204, 15);
    
-- BORROWS

INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(1, 1, '03/08/2018', '09/08/2018');
    
INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(1, 12, '06/01/2019', '24/01/2019');
    
INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(1, 13, '09/03/2019', '22/03/2019');
    
INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(1, 19, '19/12/2019', '30/12/2019');

INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(9, 6, '15/04/2019', '28/05/2019');
    
INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(9, 21, '30/08/2020', '15/09/2020');

INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(12, 1, '19/09/2020', '28/09/2020');

INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(14, 1, '02/11/2020', '14/11/2020');

INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(14, 15, '02/12/2020', '14/12/2020');
    
INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(14, 34, '02/11/2019', '14/11/2019');
    
INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(6, 2, '15/07/2017', '04/08/2017');
    
INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(6, 35, '15/07/2017', '04/08/2017');

INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(15, 23, '05/01/2021', '17/01/2021');

INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(12, 17, '18/06/2019', '30/06/2019');
    
INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(12, 9, '20/09/2019', '02/10/2019');
    
INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(6, 25, '15/03/2020', '26/03/2020');

INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(15, 8, '20/04/2020', '02/05/2020');

INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(5, 23, '20/03/2020', '02/04/2021');

INSERT INTO BORROWS(BORROWER, EXEMPLAR, BEGIN_BORROW, END_BORROW)
    VALUES(12, 2, '20/04/2021', '02/05/2021');

commit;


  